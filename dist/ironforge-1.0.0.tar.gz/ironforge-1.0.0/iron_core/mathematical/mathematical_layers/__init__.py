"""
Mathematical Layers - 5-Layer Architecture Framework
===================================================

Core mathematical abstractions for the IRON ecosystem.
"""

__all__ = []  # Components accessed through lazy loading system