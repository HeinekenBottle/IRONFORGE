"""
Iron-Core Integration Module
===========================

Cross-suite integration framework for IRON ecosystem.
Future home of cross-suite communication protocols.
"""

__all__ = []