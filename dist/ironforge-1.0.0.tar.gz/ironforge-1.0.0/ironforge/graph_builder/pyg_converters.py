from __future__ import annotations

# Placeholder converter: in a real system this would build a PyG Data object.


def igraph_to_pyg(graph):  # type: ignore[no-untyped-def]
    return graph
